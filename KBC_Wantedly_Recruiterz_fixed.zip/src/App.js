import React, { useState } from "react";

function App() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");

  const generateMessage = () => {
    if (!input) return;
    const message = `阿部様

この度は貴重なご経歴を拝見し、ご連絡させていただきました。キズキビジネスカレッジでは、「何度でもやり直せる社会をつくる」という理念のもと、うつや発達障害などにより社会から一時的に離れた方々が、自らの強みや志向性を再発見し、リスキリングを通じて適職へと進んでいただく支援を行っています。

${input.trim().slice(0, 100)}...のご経験を拝見し、当ビジネススクールのキャリアアドバイザーとして、まさに力を発揮いただけるのではないかと感じました。ご関心がございましたら、一度カジュアルにお話できましたら幸いです。`;
    setOutput(message);
  };

  return (
    <div style={{ padding: "2rem", fontFamily: "sans-serif" }}>
      <h1 style={{ textAlign: "center" }}>KBC_Wantedly_Recruiterz</h1>
      <textarea
        rows="10"
        cols="80"
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="求職者のプロフィールを貼り付けてください"
      />
      <br />
      <button onClick={generateMessage} style={{ marginTop: "1rem" }}>
        スカウト文を生成する
      </button>
      <pre style={{ marginTop: "2rem", whiteSpace: "pre-wrap" }}>{output}</pre>
    </div>
  );
}

export default App;